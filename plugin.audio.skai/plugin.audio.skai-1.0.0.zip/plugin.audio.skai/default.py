# -*- coding: utf-8 -*-
# Version 1.0.0 (08/12/2017)
# SKAI RADIO
# Greek News Channel XBMC addon
# By K.Mantzaris
# kmanjaris@gmail.com
# http://SlaXBMC.blogspot.com
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#######################################################################
import os
import sys
import xbmc
import urllib
import urllib2
import re
import xbmcplugin
import xbmcgui
import xbmcaddon
import socket
import HTMLParser
__settings__ = xbmcaddon.Addon(id='plugin.audio.skai')
__language__ = __settings__.getLocalizedString
fanart = os.path.join(__settings__.getAddonInfo('path'),'fanart.jpg')

#Load user settings
timeout = int(__settings__.getSetting("socket_timeout"))
socket.setdefaulttimeout(timeout)

#Index Menu
def INDEX(url):
	#addDir(__language__(50000),'http://www.skai.gr/player/radiolive/',1,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))
	addLink("Live Stream","http://liveradio.skai.gr/skaihd/skai/playlist.m3u8",os.path.join(__settings__.getAddonInfo('path'),'resources','images','latest.png'))
        req = urllib2.Request('http://www.skai.gr/mobile/radio/')
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) XBMC Multimedia System')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        block=re.compile('<li><a title=(.+?)" href="(.+?)">(.+?)</a></li>').findall(link)
        for buffer1,url,title in block:
                addDir(title,"http://www.skai.gr"+url,2,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))
	addSetting(__language__(50001),'plugin://plugin.radio.skai',10,os.path.join(__settings__.getAddonInfo('path'),'resources','images','settings.png'))

#LIVE RADIO
#def INDEX1(url):
#        addLink("Live Stream","http://liveradio.skai.gr/skaihd/skai/playlist.m3u8",os.path.join(__settings__.getAddonInfo('path'),'resources','images','latest.png'))
#        if xbmcplugin.getSetting(int( sys.argv[ 1 ] ),"goback") == "true":
#                addSetting('<< [ Back ]','plugin://plugin.video.skai/',11,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))

#CATEGORY LISTINGS
def INDEX2(url):
        req = urllib2.Request(str(url))
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) XBMC Multimedia System')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<li><a title=(.+?)" href="(.+?)">(.+?)</a></li>').findall(link)
        for buffer1,url,title in match:
                addDir(title,"http://www.skai.gr/"+url,3,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))
        if xbmcplugin.getSetting(int( sys.argv[ 1 ] ),"goback") == "true":
                addSetting('<< [ Back ]','plugin://plugin.radio.skai/',11,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))

#SKAI Videos
def INDEX3(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) XBMC Multimedia System')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()        
        link=normalize_link(link)
        match=re.compile('class="gals-box MultimediaItem MMID_(.+?)" href="(.+?)"><img(.+?)<h3>(.+?)</h3>(.+?)<p>(.+?)</p></a></li>').findall(link)
        for buffer1, url2, buffer2, name1, buffer3, name2 in match:
                VIDEOLINKS("http://www.skai.gr"+url2,name1+" ("+name2+")")
        if xbmcplugin.getSetting(int( sys.argv[ 1 ] ),"goback") == "true":
                addSetting('<< [ Back ]','plugin://plugin.radio.skai/',11,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))

def VIDEOLINKS(url,name):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) XBMC Multimedia System')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        link=normalize_link(link)
        match=re.compile('sourceUrl:  \'(.+?)\',(.+?)mediaImg:\'(.+?)\',(.+?)mediaTitle:"(.+?)",').findall(link)
        for surl, buffer1, thumb, buffer2, name2 in match:
                addLink(name,surl,thumb)


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

def addLink(name,url,iconimage):
        ok=True
        icoimg = os.path.join(__settings__.getAddonInfo('path'),iconimage)
        if icoimg.count('http:') > 0:
                icoimg=iconimage        
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Audio", infoLabels={ "Title": name } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def addYTLink(name,url,ytid,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&ytid="+str(ytid)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        icoimg = os.path.join(__settings__.getAddonInfo('path'),iconimage)
        if icoimg.count('http:') > 0:
                icoimg=iconimage        
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Audio", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable","true")
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
        return ok

def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        icoimg = os.path.join(__settings__.getAddonInfo('path'),iconimage)
        if icoimg.count('http:') > 0:
                icoimg=iconimage
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=icoimg)
        liz.setInfo( type="Audio", infoLabels={ "Title": name } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addSetting(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        icoimg = os.path.join(__settings__.getAddonInfo('path'),iconimage)
        if icoimg.count('http:') > 0:
                icoimg=iconimage
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=icoimg)
        liz.setInfo( type="Audio", infoLabels={ "Title": name } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok 

def normalize_link(link):
        match=re.compile('charset=(.+?)"').findall(link)
        if not match:
                link=link.replace('\t','').replace('\r\n','').replace('\n','')
                return link
        elif match[0].upper() == "UTF-8":
                link=link.replace('\t','').replace('\r\n','').replace('\n','')
                return link
        else:
                link=link.replace('\t','').replace('\r\n','').replace('\n','').decode(match[0]).encode('utf-8')
                return link

def LoadSettings():
        __settings__.openSettings(sys.argv[ 0 ])
        timeout = int(__settings__.getSetting("socket_timeout"))
        socket.setdefaulttimeout(timeout)

def PageBack():
        xbmc.executebuiltin( "XBMC.Action(Back)" )

params=get_params()
url=None
name=None
mode=None
ytid=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        ytid=urllib.unquote_plus(params["ytid"])
except:
        pass


#print "Mode: "+str(mode)
#print "URL: "+str(url)
#print "Name: "+str(name)
#print "YTid: "+str(ytid)

if mode==None or url==None or len(url)<1:
        INDEX(url)
elif mode==1:
	INDEX1(url)
elif mode==2:
	INDEX2(url)
elif mode==3:
	INDEX3(url)	
elif mode==10:
	LoadSettings()
elif mode==11:
	PageBack()	
elif mode==20:
        VIDEOLINKS(url,name)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
