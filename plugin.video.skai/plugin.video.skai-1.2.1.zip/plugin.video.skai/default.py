# -*- coding: utf-8 -*-
# Version 1.2.1 (26/01/2014)
# SKAI TV
# Greek News Channel XBMC addon
# By K.Mantzaris
# kmanjaris@gmail.com
# http://SlaXBMC.blogspot.com
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#######################################################################
import os
import sys
import xbmc
import urllib
import urllib2
import re
import xbmcplugin
import xbmcgui
import xbmcaddon
import socket
import HTMLParser
__settings__ = xbmcaddon.Addon(id='plugin.video.skai')
__language__ = __settings__.getLocalizedString
fanart = os.path.join(__settings__.getAddonInfo('path'),'fanart.jpg')

#Load user settings
timeout = int(__settings__.getSetting("socket_timeout"))
socket.setdefaulttimeout(timeout)

#Index Menu
def INDEX(url):
	addDir(__language__(50000),'http://www.skai.gr/player/tvlive/',1,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))
        req = urllib2.Request('http://www.skai.gr/player/tv/')
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) XBMC Multimedia System')
        #req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        link=normalize_link(link).replace('<li class="megamenu_right">','<li id="26"')
        block=re.compile('class="megamenu_drop">(.+?)</a>(.+?)<li id="').findall(link)
        for category,rest in block:
                if category.find('class=') == -1:
                        addDir(category,rest,2,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))
	addSetting(__language__(50001),'plugin://plugin.video.skai',10,os.path.join(__settings__.getAddonInfo('path'),'resources','images','settings.png'))

#LIVE TV
def INDEX1(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) XBMC Multimedia System')
        #req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        link=normalize_link(link)
        match=re.compile('id="p-title">(.+?)</span>(.+?)id="p-file">(.+?)</span><span id="p-image">(.+?)</span>').findall(link)
        for name,buffer1,ytid,thumb in match:
                addYTLink(name,"http://www.skai.gr/player/tvlive/",ytid,21,thumb)    
        if xbmcplugin.getSetting(int( sys.argv[ 1 ] ),"setytlink") == "true":
                req = urllib2.Request(url)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) XBMC Multimedia System')
                #req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                addYTLink("ΣΚΑΪ YouTube Live","http://www.skai.gr/player/tvlive/",xbmcplugin.getSetting(int( sys.argv[ 1 ] ),"getytid"),21,os.path.join(__settings__.getAddonInfo('path'),'resources','images','latest.png'))
        getAlt = xbmcplugin.getSetting(int( sys.argv[ 1 ] ),"iphone_livestream")
        if getAlt == "true":
                req = urllib2.Request("http://www.skai.gr/mobile/tv-live/")
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) XBMC Multimedia System')
                #req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                iblock=re.compile('<video width=(.+?)src=\'(.+?)\'').findall(link)
                if iblock:
                        addLink("[iPhone] Live Stream",iblock[0][1],os.path.join(__settings__.getAddonInfo('path'),'resources','images','latest.png'))
        if xbmcplugin.getSetting(int( sys.argv[ 1 ] ),"goback") == "true":
                addSetting('<< [ Back ]','plugin://plugin.video.skai/',11,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))

#CATEGORY LISTINGS
def INDEX2(url):
        link=normalize_link(url)
        match=re.compile('id="(.+?)"><a(.+?)">(.+?)</a></li>').findall(link)     
        for CID, buffer1, name in match:
                addDir(name,"http://www.skai.gr/Ajax.aspx?m=Nv.SqlModule&name=player_media_list_cat&pg=1&categoryid="+str(CID)+"&mediatype=TV",3,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))
        if xbmcplugin.getSetting(int( sys.argv[ 1 ] ),"goback") == "true":
                addSetting('<< [ Back ]','plugin://plugin.video.skai/',11,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))

#SKAI Videos
def INDEX3(url):
        VIDEOPAGE(url)
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) XBMC Multimedia System')
        #req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        link=normalize_link(link)
        block=re.compile('PagerLink active">(.+?)</a>(.+?)class="paging-right(.+?)P_(.+?)"').findall(link)
        if block:
                for pactive, buffer1, buffer2, pend in block:                 
                        if int(pactive) < int(pend):
                                first=url.split('pg=')[0]
                                second=url.split('&categoryid=')[1]
                                url=first+"pg="+str(int(pactive)+1)+"&categoryid="+second
                                addDir('>> [ '+str(int(pactive)+1)+' ] :: Επόμενη Σελίδα ::',url,3,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))
                        if int(pactive) > 1:
                                addSetting('<< [ '+str(int(pactive)-1)+' ] :: Προηγούμενη Σελίδα ::','plugin://plugin.video.skai/',11,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))
                        if int(pactive) == 1:
                                if xbmcplugin.getSetting(int( sys.argv[ 1 ] ),"goback") == "true":
                                        addSetting('<< [ Back ]','plugin://plugin.video.skai/',11,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))
        else:
                if xbmcplugin.getSetting(int( sys.argv[ 1 ] ),"goback") == "true":
                        addSetting('<< [ Back ]','plugin://plugin.video.skai/',11,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))
                return

def VIDEOPAGE(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) XBMC Multimedia System')
        #req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()        
        link=normalize_link(link)
        match=re.compile('<a href="/player(.+?)"(.+?)src="(.+?)"(.+?)<time>(.+?)</time><br>(.+?)</p>').findall(link)
        for mmidurl, buffer1, thumb, buffer2, name1, name2 in match:
                if xbmcplugin.getSetting(int( sys.argv[ 1 ] ),"sclist") == "true":
                        VIDEOLINKS("http://www.skai.gr/player"+mmidurl,name1 + " " + name2)
                else:
                        addDir(name1 + " " + name2,"http://www.skai.gr/player"+mmidurl,20,thumb)

def VIDEOLINKS(url,name):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) XBMC Multimedia System')
        #req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        link=normalize_link(link)
        match=re.compile('id="p-title">(.+?)</span>(.+?)id="p-file">(.+?)</span>(.+?)id="p-image">(.+?)</span>').findall(link)
        for newname, buffer1, url, buffer2, thumb in match:
                addLink(name,url,thumb)

def VIDEOLINKSYT(ytid):
        xbmc_url = 'plugin://plugin.video.youtube/?path=root/video&action=play_video&videoid='+str(ytid)
        li = xbmcgui.ListItem("testing",path=xbmc_url)
        li.setProperty("IsPlayable","true")
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

def addLink(name,url,iconimage):
        ok=True
        icoimg = os.path.join(__settings__.getAddonInfo('path'),iconimage)
        if icoimg.count('http:') > 0:
                icoimg=iconimage        
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def addYTLink(name,url,ytid,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&ytid="+str(ytid)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        icoimg = os.path.join(__settings__.getAddonInfo('path'),iconimage)
        if icoimg.count('http:') > 0:
                icoimg=iconimage        
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable","true")
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
        return ok

def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        icoimg = os.path.join(__settings__.getAddonInfo('path'),iconimage)
        if icoimg.count('http:') > 0:
                icoimg=iconimage
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=icoimg)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addSetting(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        icoimg = os.path.join(__settings__.getAddonInfo('path'),iconimage)
        if icoimg.count('http:') > 0:
                icoimg=iconimage
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=icoimg)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok 

def normalize_link(link):
        match=re.compile('charset=(.+?)"').findall(link)
        if not match:
                link=link.replace('\t','').replace('\r\n','').replace('\n','')
                return link
        elif match[0].upper() == "UTF-8":
                link=link.replace('\t','').replace('\r\n','').replace('\n','')
                return link
        else:
                link=link.replace('\t','').replace('\r\n','').replace('\n','').decode(match[0]).encode('utf-8')
                return link

def LoadSettings():
        __settings__.openSettings(sys.argv[ 0 ])
        timeout = int(__settings__.getSetting("socket_timeout"))
        socket.setdefaulttimeout(timeout)

def PageBack():
        xbmc.executebuiltin( "XBMC.Action(Back)" )

params=get_params()
url=None
name=None
mode=None
ytid=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        ytid=urllib.unquote_plus(params["ytid"])
except:
        pass


#print "Mode: "+str(mode)
#print "URL: "+str(url)
#print "Name: "+str(name)
#print "YTid: "+str(ytid)

if mode==None or url==None or len(url)<1:
        INDEX(url)
elif mode==1:
	INDEX1(url)
elif mode==2:
	INDEX2(url)
elif mode==3:
	INDEX3(url)	
elif mode==10:
	LoadSettings()
elif mode==11:
	PageBack()	
elif mode==20:
        VIDEOLINKS(url,name)
elif mode==21:
        VIDEOLINKSYT(ytid)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
