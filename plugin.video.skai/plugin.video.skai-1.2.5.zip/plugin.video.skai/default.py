# -*- coding: utf-8 -*-
# Version 1.2.5 (03/03/2019)
# SKAI TV
# Greek News Channel XBMC addon
# By K.Mantzaris
# kmanjaris@gmail.com
# http://SlaXBMC.blogspot.com
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#######################################################################
import os
import sys
import xbmc
import urllib
import urllib2
import re
import xbmcplugin
import xbmcgui
import xbmcaddon
import socket
import HTMLParser
import json
__settings__ = xbmcaddon.Addon(id='plugin.video.skai')
__language__ = __settings__.getLocalizedString
fanart = os.path.join(__settings__.getAddonInfo('path'),'fanart.jpg')

#Load user settings
timeout = int(__settings__.getSetting("socket_timeout"))
socket.setdefaulttimeout(timeout)

#Index Menu
def INDEX(url):
	addDir(__language__(50000),'http://www.skaitv.gr/tvlive/',1,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))
	req=urllib2.Request('http://www.skaitv.gr/json/show_categories.php')
	req.add_header('Accept', '*/*')
	req.add_header('Referer', 'http://www.skaitv.gr/shows/enimerosi')
	req.add_header('User-Agent', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) XBMC Multimedia System')
	req.add_header('X-Requested-With', 'XMLHttpRequest')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	main_json = json.loads(link)
	for x in range(len(main_json['show_categories'])):
	    addDir(main_json['show_categories'][x]['title'].encode('utf-8'),'http://www.skaitv.gr/json/shows.php?caption='+main_json['show_categories'][x]['caption'].encode('utf-8')+'&text=&now=1',2,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))
	req=urllib2.Request('http://www.skaitv.gr/json/shows.php?caption=&text=&now=1')
	req.add_header('Accept', '*/*')
	req.add_header('Connection', 'keep-alive')
	req.add_header('Referer', 'http://www.skaitv.gr/live')
	req.add_header('Connection', 'keep-alive')
	req.add_header('User-Agent', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) XBMC Multimedia System')
	req.add_header('X-Requested-With', 'XMLHttpRequest')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	main_json = json.loads(link)
	addDir(main_json['shows'][0]['subtitle'].encode('utf-8'),'http://www.skaitv.gr/json/shows.php?caption=enimerosi&text=&now=2',2,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))             
	addSetting(__language__(50001),'plugin://plugin.video.skai',10,os.path.join(__settings__.getAddonInfo('path'),'resources','images','settings.png'))

#LIVE TV
def INDEX1(url):
	req=urllib2.Request('http://www.skaitv.gr/json/live.php')
	req.add_header('Accept', '*/*')
	req.add_header('Connection', 'keep-alive')
	req.add_header('Referer', 'http://www.skaitv.gr/live')
	req.add_header('Connection', 'keep-alive')
	req.add_header('User-Agent', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) XBMC Multimedia System')
	req.add_header('X-Requested-With', 'XMLHttpRequest')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	match=link.split('"next"')
	for x in range(len(match)):
	    if "livestream" in match[x]:
		sTitle=match[x].split('"title":')[1].split(',')[0].replace('"',"").strip()
		sYTid=match[x].split('"livestream":')[1].split(',')[0].replace('"',"").strip().split('v=')[1]
		addYTLink(sTitle,"http://www.skaitv.gr/live/",sYTid,21,os.path.join(__settings__.getAddonInfo('path'),'resources','images','latest.png'))

#CATEGORY LISTINGS
def INDEX2(url):
	if int(url[-1]) == 2:
	  req=urllib2.Request('http://www.skaitv.gr/json/shows.php?caption=enimerosi&text=&now=1')
	  req.add_header('Accept', '*/*')
	  req.add_header('Referer', 'http://www.skaitv.gr/shows/enimerosi')
	  req.add_header('User-Agent', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) XBMC Multimedia System')
	  req.add_header('X-Requested-With', 'XMLHttpRequest')
	  response = urllib2.urlopen(req)
	  link=response.read()
	  response.close()
	  main_json = json.loads(link)
	  for x in range(len(main_json['shows'])):
	    addDir(main_json['shows'][x]['title'].encode('utf-8'),'http://www.skaitv.gr/json/show.php?caption='+main_json['shows'][x]['link'].split('/')[-1].encode('utf-8')+'&cat_caption='+main_json['shows'][x]['link'].split('/')[-3].encode('utf-8')+'&cat_caption2='+main_json['shows'][x]['link'].split('/')[-2].encode('utf-8'),3,'http:'+main_json['shows'][x]['img'].encode('utf-8'))
	else:
	  req=urllib2.Request(url)
	  req.add_header('Accept', '*/*')
	  req.add_header('Referer', 'http://www.skaitv.gr/shows/enimerosi')
	  req.add_header('User-Agent', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) XBMC Multimedia System')
	  req.add_header('X-Requested-With', 'XMLHttpRequest')
	  response = urllib2.urlopen(req)
	  link=response.read()
	  response.close()
	  main_json = json.loads(link)
	  for x in range(len(main_json['now_shows'])):
	      addDir(main_json['now_shows'][x]['title'].encode('utf-8'),'http://www.skaitv.gr/json/show.php?caption='+main_json['now_shows'][x]['link'].split('/')[-1].encode('utf-8')+'&cat_caption='+str(url).split('=')[-3].split('&')[0]+'&cat_caption2='+main_json['now_shows'][x]['link'].split('/')[-2].encode('utf-8'),3,'http:'+main_json['now_shows'][x]['img'].encode('utf-8'))
	if xbmcplugin.getSetting(int( sys.argv[ 1 ] ),"goback") == "true":
	  addSetting('<< [ Back ]','plugin://plugin.video.skai/',11,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))

#SKAI Videos
def INDEX3(url):
	req=urllib2.Request(url)
	req.add_header('Accept', '*/*')
	req.add_header('Referer', 'http://www.skaitv.gr/shows/enimerosi')
	req.add_header('User-Agent', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) XBMC Multimedia System')
	req.add_header('X-Requested-With', 'XMLHttpRequest')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	main_json = json.loads(link)
	for x in range(len(main_json['episodes_last'])):
	  addDir(main_json['episodes_last'][x]['title'].encode('utf-8')+' ('+main_json['episodes_last'][x]['start'].split(' ')[0].encode('utf-8')+')','http://www.skaitv.gr/json/episode.php?caption=no&show_caption='+main_json['episodes_last'][x]['link'].split('/')[-1].encode('utf-8')+'&epanalipsi=&cat_caption2='+main_json['episodes_last'][x]['link'].split('/')[-2].encode('utf-8'),20,'http:'+main_json['episodes_last'][x]['img'].encode('utf-8'))
	if xbmcplugin.getSetting(int( sys.argv[ 1 ] ),"goback") == "true":
	  addSetting('<< [ Back ]','plugin://plugin.video.skai/',11,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))


def VIDEOPAGE(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) XBMC Multimedia System')
        #req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()        
        link=normalize_link(link)
        match=re.compile('<a href="/player(.+?)"(.+?)src="(.+?)"(.+?)<time>(.+?)</time><br>(.+?)</p>').findall(link)
        for mmidurl, buffer1, thumb, buffer2, name1, name2 in match:
                if xbmcplugin.getSetting(int( sys.argv[ 1 ] ),"sclist") == "true":
                        VIDEOLINKS("http://www.skai.gr/player"+mmidurl,name1 + " " + name2)
                else:
                        addDir(name1 + " " + name2,"http://www.skai.gr/player"+mmidurl,20,thumb)


def VIDEOLINKS(url,name):
	req=urllib2.Request(url)
	req.add_header('Accept', '*/*')
	req.add_header('Referer', 'http://www.skaitv.gr/shows/enimerosi')
	req.add_header('User-Agent', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) XBMC Multimedia System')
	req.add_header('X-Requested-With', 'XMLHttpRequest')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	main_json = json.loads(link)
	for x in range(len(main_json['episode'])):
	  addLink(main_json['episode'][x]['media_item_title'].encode('utf-8'),str('http://videostream.skai.gr/'+main_json['episode'][x]['media_item_file'].encode('utf-8')).replace('.gr//','.gr/')+'.m3u8','http:'+main_json['episode'][x]['mi_img'].encode('utf-8'))
	if xbmcplugin.getSetting(int( sys.argv[ 1 ] ),"goback") == "true":
	  addSetting('<< [ Back ]','plugin://plugin.video.skai/',11,os.path.join(__settings__.getAddonInfo('path'),'resources','images','defFolder.png'))


def VIDEOLINKSYT(ytid):
        #xbmc_url = 'plugin://plugin.video.youtube/?path=root/video&action=play_video&videoid='+str(ytid)
        xbmc_url = 'plugin://plugin.video.youtube/play/?video_id='+str(ytid)
        li = xbmcgui.ListItem("testing",path=xbmc_url)
        li.setProperty("IsPlayable","true")
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

def addLink(name,url,iconimage):
        ok=True
        icoimg = os.path.join(__settings__.getAddonInfo('path'),iconimage)
        if icoimg.count('http:') > 0:
                icoimg=iconimage        
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def addYTLink(name,url,ytid,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&ytid="+str(ytid)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        icoimg = os.path.join(__settings__.getAddonInfo('path'),iconimage)
        if icoimg.count('http:') > 0:
                icoimg=iconimage        
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable","true")
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
        return ok

def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        icoimg = os.path.join(__settings__.getAddonInfo('path'),iconimage)
        if icoimg.count('http:') > 0:
                icoimg=iconimage
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=icoimg)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addSetting(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        icoimg = os.path.join(__settings__.getAddonInfo('path'),iconimage)
        if icoimg.count('http:') > 0:
                icoimg=iconimage
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=icoimg)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok 

def normalize_link(link):
        match=re.compile('charset=(.+?)"').findall(link)
        if not match:
                link=link.replace('\t','').replace('\r\n','').replace('\n','')
                return link
        elif match[0].upper() == "UTF-8":
                link=link.replace('\t','').replace('\r\n','').replace('\n','')
                return link
        else:
                link=link.replace('\t','').replace('\r\n','').replace('\n','').decode(match[0]).encode('utf-8')
                return link

def LoadSettings():
        __settings__.openSettings(sys.argv[ 0 ])
        timeout = int(__settings__.getSetting("socket_timeout"))
        socket.setdefaulttimeout(timeout)

def PageBack():
        xbmc.executebuiltin( "XBMC.Action(Back)" )

params=get_params()
url=None
name=None
mode=None
ytid=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        ytid=urllib.unquote_plus(params["ytid"])
except:
        pass


#print "Mode: "+str(mode)
#print "URL: "+str(url)
#print "Name: "+str(name)
#print "YTid: "+str(ytid)

if mode==None or url==None or len(url)<1:
        INDEX(url)
elif mode==1:
	INDEX1(url)
elif mode==2:
	INDEX2(url)
elif mode==3:
	INDEX3(url)
elif mode==10:
	LoadSettings()
elif mode==11:
	PageBack()
elif mode==20:
        VIDEOLINKS(url,name)
elif mode==21:
        VIDEOLINKSYT(ytid)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
