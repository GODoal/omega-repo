# -*- coding: utf-8 -*-
# Version 1.1.2 (27/10/2012)
# SKAI TV
# Greek News Channel XBMC addon
# By K.Mantzaris
# kmanjaris@gmail.com
# http://SlaXBMC.blogspot.com
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#######################################################################
import os
import sys
import xbmc
import urllib
import urllib2
import re
import xbmcplugin
import xbmcgui
import xbmcaddon
import socket
import HTMLParser
__settings__ = xbmcaddon.Addon(id='plugin.video.skai')
__language__ = __settings__.getLocalizedString


#Load user settings
timeout = int(__settings__.getSetting("socket_timeout"))
socket.setdefaulttimeout(timeout)

#Index Menu
def INDEX(url):
	addDir(__language__(50000),'http://www.skai.gr/player/tvlive/',1,os.path.join(__settings__.getAddonInfo('path'),'resources','images','tv.png'))
	addDir(__language__(50001),'http://www.skai.gr/player/tv/',2,os.path.join(__settings__.getAddonInfo('path'),'resources','images','video.png'))
	addDir(__language__(50002),'http://www.skai.gr/player/tv/',3,os.path.join(__settings__.getAddonInfo('path'),'resources','images','archives.png'))
	addSetting(__language__(50003),'plugin://plugin.video.skai',10,os.path.join(__settings__.getAddonInfo('path'),'resources','images','settings.png'))

#SKAI Live
def INDEX1(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        link=link.replace('\t','').replace('\r\n','').replace('\n','')
        match=re.compile('<h2 style="text-align:center">(.+?)</h2>(.+?)else {infos = "(.+?)";(.+?)var File = "(.+?)";(.+?)ScreenImage = "(.+?)";').findall(link)
        for name1,buffer1,name2,buffer3,ytid,buffer4,thumb in match:
                if ytid.find('.flv') >= 0:
                        addYTLink(name1,"http://www.skai.gr/player/tvlive/","VbjwSCS_leE",22,thumb)
                else:
                        addYTLink(name2,"http://www.skai.gr/player/tvlive/",ytid,22,thumb)
        if xbmcplugin.getSetting(int( sys.argv[ 1 ] ),"setytlink") == "true":
                req = urllib2.Request(url)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                addYTLink("ΣΚΑΪ YouTube Live","http://www.skai.gr/player/tvlive/",xbmcplugin.getSetting(int( sys.argv[ 1 ] ),"getytid"),22,os.path.join(__settings__.getAddonInfo('path'),'resources','images','latest.png'))
        getAlt = xbmcplugin.getSetting(int( sys.argv[ 1 ] ),"iphone_livestream")
        if getAlt == "true":
                addLink("[iPhone] Live Stream","http://iphone.skai.gr.edgesuite.net/iphone_iphone.m3u8",os.path.join(__settings__.getAddonInfo('path'),'resources','images','latest.png'))

#SKAI Videos
def INDEX2(url):
        for num in range(1,6):
            adr="http://www.skai.gr/ajax.aspx?m=Skai.Player.ItemView&alid=&cid=&MMID=&dateFrom=&dateTo=&Page=" + str(num) + "&ct=147"
            req = urllib2.Request(adr)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
            response = urllib2.urlopen(req)
            link=response.read()
            response.close()
            a=re.compile('<a border="0" href="#" class="gals-box MultimediaItem MMID_(.+?)"><img border="0" src="(.+?)"><strong>(.+?)</strong><em>(.+?)</em></a>')
            match=a.findall(link)     
            for url,thumb,name1,name2 in match:
                addDir(name1 + " " + name2,"http://www.skai.gr/player/tv/?MMID="+url,20,thumb)

def INDEX3(url):
        req = urllib2.Request('http://www.skai.gr/player/tvlive/')
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        link=link.replace('\t','').replace('\r\n','').replace('\n','')
        a=re.compile('CategoryLink CID_(.+?)" href="(.+?)">(.+?)</a></li>')
        match=a.findall(link)     
        for CID, buffer1,name in match:
                if int(CID) > 0:
                        addDir(name,"http://www.skai.gr/ajax.aspx?m=Skai.Player.AlbumsView&cid="+str(CID)+"&MMID=&ct=146",4,os.path.join(__settings__.getAddonInfo('path'),'resources','images','archives.png'))

def INDEX4(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        a=re.compile('CategoryLink ALID_(.+?) CID_(.+?) " href="#" title="">(.+?)<span>')
        match=a.findall(link)     
        for ALID, CID, name in match:        
	    addDir(name.replace('amp;',''),"http://www.skai.gr/ajax.aspx?m=Skai.Player.ItemView&alid="+str(ALID)+"&cid="+str(CID)+"&MMID=&dateFrom=&dateTo=&Page=",5,os.path.join(__settings__.getAddonInfo('path'),'resources','images','archives.png'))

def INDEX5(url):
        eurl = url
        req = urllib2.Request(eurl+"1&ct=147")
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        link=link.replace('\t','').replace('\r\n','').replace('\n','')
        a=re.compile('class="paging-right P_(.+?)">')
        match=a.findall(link)
        if not match:
                iMaxPage = 2
        else:
                iMaxPage=match[0]
        for num in range(1,int(iMaxPage)):
                adr=eurl + str(num) + "&ct=147"
                req = urllib2.Request(adr)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                link=link.replace('\t','').replace('\r\n','').replace('\n','')
                a=re.compile('<a border="0" href="#" class="gals-box MultimediaItem MMID_(.+?)"><img border="0" src="(.+?)"><strong>(.+?)</strong><em>(.+?)</em></a>')
                match=a.findall(link)     
                for url,thumb,name1,name2 in match:
                        getThumbs = xbmcplugin.getSetting(int( sys.argv[ 1 ] ),"lazy_thumb")
                        if getThumbs == "false":
                                aurl="http://www.skai.gr/player/tv/?MMID="+url
                                req = urllib2.Request(aurl)
                                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
                                response = urllib2.urlopen(req)
                                alink=response.read()
                                response.close()
                                alink=alink.replace('\t','').replace('\r\n','').replace('\n','')
                                a=re.compile('flowplayer_config_dependon_show(.+?),"(.+?)","(.+?)","(.+?)","')
                                matchimg=a.findall(alink)
                                addDir(name1+" "+name2,url,21,str(matchimg[0][2]))
                        else:
                                addDir(name1+" "+name2,url,21,thumb)

def VIDEOLINKS1(url,name):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        link=link.replace('\t','').replace('\r\n','').replace('\n','')
        a=re.compile('"rtmp://(.+?)","(.+?)","(.+?)","')
        match=a.findall(link)
        for url,thumb,name in match:
                addLink(name,"rtmp://"+url,thumb)

def VIDEOLINKS2(url,name):
        url2="http://www.skai.gr/player/tv/?MMID="+url
        req = urllib2.Request(url2)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        link=link.replace('\t','').replace('\r\n','').replace('\n','')
        a=re.compile('"rtmp://(.+?)","(.+?)","(.+?)","')
        match=a.findall(link)
        for url,thumb,name in match:
                addLink(name,"rtmp://"+url,thumb)

def VIDEOLINKS3(ytid):
        xbmc_url = 'plugin://plugin.video.youtube/?path=root/video&action=play_video&videoid='+str(ytid)
        li = xbmcgui.ListItem("testing",path=xbmc_url)
        li.setProperty("IsPlayable","true")
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

def addLink(name,url,iconimage):
        ok=True
        icoimg = os.path.join(__settings__.getAddonInfo('path'),iconimage)
        if icoimg.count('http:') > 0:
                icoimg=iconimage        
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def addYTLink(name,url,ytid,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&ytid="+str(ytid)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        icoimg = os.path.join(__settings__.getAddonInfo('path'),iconimage)
        if icoimg.count('http:') > 0:
                icoimg=iconimage        
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
        return ok

def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        icoimg = os.path.join(__settings__.getAddonInfo('path'),iconimage)
        if icoimg.count('http:') > 0:
                icoimg=iconimage
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=icoimg)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addSetting(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        icoimg = os.path.join(__settings__.getAddonInfo('path'),iconimage)
        if icoimg.count('http:') > 0:
                icoimg=iconimage
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=icoimg)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok 

def LoadSettings():
        __settings__.openSettings(sys.argv[ 0 ])
        timeout = int(__settings__.getSetting("socket_timeout"))
        socket.setdefaulttimeout(timeout)


params=get_params()
url=None
name=None
mode=None
ytid=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        ytid=urllib.unquote_plus(params["ytid"])
except:
        pass

#print "Mode: "+str(mode)
#print "URL: "+str(url)
#print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        INDEX(url)
elif mode==1:
	INDEX1(url)
elif mode==2:
	INDEX2(url)
elif mode==3:
	INDEX3(url)
elif mode==4:
	INDEX4(url)
elif mode==5:
	INDEX5(url)
elif mode==10:
	LoadSettings()	
elif mode==20:
        VIDEOLINKS1(url,name)
elif mode==21:
        VIDEOLINKS2(url,name)
elif mode==22:
        VIDEOLINKS3(ytid)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
