# Version 1.0.5 (28/10/2011)
# SKAI TV
# Greek News Channel XBMC addon
# By K.Mantzaris
# kmanjaris@gmail.com
# http://SlaXBMC.blogspot.com
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#######################################################################
import sys,os,xbmc,urllib,urllib2,re,xbmcplugin,xbmcgui,xbmcaddon
__settings__ = xbmcaddon.Addon(id='plugin.video.skai')


#Index Menu
def INDEX(url):
	addDir('TV Now','http://www.skai.gr/player/tvlive/',1,'tv.png')
	addDir('TV Videos','http://www.skai.gr/player/tv/',2,'video.png')
	addDir('TV Archives','http://www.skai.gr/player/tv/',3,'archives.png')

#SKAI Live
def INDEX1(url):
        req = urllib2.Request('http://www.skai.gr/player/tvlive/')
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        a=re.compile('P.Options.Skai.videoTitle = "(.+?)";\n(.+?)P.Options.Skai.symbol = "(.+?)";\n(.+?)P.Options.Skai.videoTime = "";\n(.+?)P.Options.Skai.videoInfos = infos;\n(.+?)P.Options.File = "(.+?)";\n(.+?)P.Options.Play = "true";\n(.+?)\n(.+?)P.Options.Screenshot = "(.+?)";')
        match=a.findall(link)     
        for name,buffer1,symbol,buffer2,buffer3,buffer4,url,buffer5,buffer6,buffer7,thumb in match:        
	    addDir(name,url+" swfurl=http://www.skai.gr/files/1/Flash/Shows/SkaiMediaPlayer.swf swfvfy=true live=true",20,thumb)

#SKAI Videos
def INDEX2(url):
        for num in range(1,6):
            adr="http://www.skai.gr/ajax.aspx?m=Skai.Player.ItemView&alid=&cid=&MMID=&dateFrom=&dateTo=&Page=" + str(num) + "&ct=147"
            req = urllib2.Request(adr)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
            response = urllib2.urlopen(req)
            link=response.read()
            response.close()
            a=re.compile('<a border="0" href="#" class="gals-box MultimediaItem MMID_(.+?)"><img border="0" src="(.+?)"><strong>(.+?)</strong><em>(.+?)</em></a>')
            match=a.findall(link)     
            for url,thumb,name1,name2 in match:
                addDir(name1 + " " + name2,"http://www.skai.gr/player/tv/?MMID="+url,21,thumb)

#SKAI Archives
def INDEX3(url):
        for num in range(1,6):
            adr="http://www.skai.gr/ajax.aspx?m=Skai.Player.ItemView&alid=&cid=&MMID=&dateFrom=&dateTo=&Page=" + str(num) + "&ct=147"
            req = urllib2.Request(adr)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
            response = urllib2.urlopen(req)
            link=response.read()
            response.close()
            a=re.compile('<a border="0" href="#" class="gals-box MultimediaItem MMID_(.+?)"><img border="0" src="(.+?)"><strong>(.+?)</strong><em>(.+?)</em></a>')
            match=a.findall(link)     
            for url,thumb,name1,name2 in match:
                addDir(name1,url,22,thumb)

                

def VIDEOLINKS1(url,name):
        addLink(name,url,'')


def VIDEOLINKS2(url,name):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        a=re.compile('flowplayer_conf(.+?)"(.+?)",\n\t\t\t"(.+?)",\n\t\t\t"(.+?)",\n\t\t\t')
        match=a.findall(link)
        for dummy,url,thumb,name in match:
            addLink(name,url,thumb)

def VIDEOLINKS3(url,name):
        adr="http://www.skai.gr/ajax.aspx?m=Skai.Player.ItemView&alid=&cid=&MMID=" + str(url) + "&dateFrom=&dateTo=&Page=1&ct=147"
        req = urllib2.Request(adr)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        a=re.compile('PagerLink ">(.+?)</a><a href="#" onclick=')
        match=a.findall(link)
        if not match:
                iMaxPage = 2
        else:
                iMaxPage=match[0]
        for num in range(1,int(iMaxPage)):
                adr="http://www.skai.gr/ajax.aspx?m=Skai.Player.ItemView&alid=&cid=&MMID=" + str(url) + "&dateFrom=&dateTo=&Page=" + str(num) + "&ct=147"
                req = urllib2.Request(adr)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                a=re.compile('<a border="0" href="#" class="gals-box MultimediaItem MMID_(.+?)"><img border="0" src="(.+?)"><strong>(.+?)</strong><em>(.+?)</em></a>')
                match=a.findall(link)
                for url,thumb,name1,name2 in match:
                        url2="http://www.skai.gr/player/tv/?MMID="+url
                        req = urllib2.Request(url2)
                        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
                        response = urllib2.urlopen(req)
                        link=response.read()
                        response.close()
                        a=re.compile('flowplayer_conf(.+?)"(.+?)",\n\t\t\t"(.+?)",\n\t\t\t"(.+?)",\n\t\t\t')
                        match=a.findall(link)
                        for dummy,url,thumb,name3 in match:
                                addLink(name3+" "+name2,url,thumb)


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        icoimg = os.path.join(__settings__.getAddonInfo('path'),iconimage)
        if icoimg.count('http:') > 0:
                icoimg=iconimage
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=icoimg)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        INDEX(url)
elif mode==1:
	print ""
	INDEX1(url)
elif mode==2:
	print ""
	INDEX2(url)
elif mode==3:
	print ""
	INDEX3(url)	
elif mode==20:
        print ""+url
        VIDEOLINKS1(url,name)
elif mode==21:
        print ""+url
        VIDEOLINKS2(url,name)
elif mode==22:
        print ""+url
        VIDEOLINKS3(url,name)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
